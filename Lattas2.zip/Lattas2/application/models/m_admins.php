<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class m_admins extends CI_Model {

	//Query Alumni
	public function tampil_alumni_lulus()
	{
		$this->db->select('*');
		$this->db->from('alumni');
		$this->db->where('keterangan','Lulus');
		return $this->db->get();
	}
	
	public function tampil_alumni_tlulus()
	{
		$this->db->select('*');
		$this->db->from('alumni');
		$this->db->where('keterangan','Tidak Lulus');
		return $this->db->get();
	}
	
	public function hapus_alumni($id)
	{
		return $this->db->delete('alumni', array('kode_alumni' => $id));
	}
	
	function data_alumni_lulus($number,$offset){
		$this->db->where('keterangan','Lulus');
		return $query = $this->db->get('alumni',$number,$offset)->result();		
	}
	
	function data_alumni_tlulus($number,$offset){
		$this->db->where('keterangan','Tidak Lulus');
		return $query = $this->db->get('alumni',$number,$offset)->result();		
	}
 
	function jumlah_alumni_lulus(){
		return $this->db->get('alumni')->num_rows();
	}
	
	function jumlah_alumni_tlulus(){
		return $this->db->get('alumni')->num_rows();
	}
	
	//Query Lembaga
	public function tampil_lembaga()
	{
		return $this->db->get('lembaga');
	}

	public function hapus_lembaga($id)
	{
		return $this->db->delete('lembaga', array('kode_lembaga' => $id));
	}
	
	function data_lembaga($number,$offset){
		return $query = $this->db->get('lembaga',$number,$offset)->result();		
	}
 
	function jumlah_lembaga(){
		return $this->db->get('lembaga')->num_rows();
	}
	
	//Query Kejuruan
	public function tampil_kejuruan()
	{
		return $this->db->get('kejuruan');
	}

	public function hapus_kejuruan($id)
	{
		return $this->db->delete('kejuruan', array('kode_kejuruan' => $id));
	}
	
	//Query Penempatan
	public function tampil_penempatan()
	{
		return $this->db->get('penempatan');
	}

	public function hapus_penempatan($id)
	{
		return $this->db->delete('penempatan', array('kode_penempatan' => $id));
	}
	
	function data_penempatan($number,$offset){
		return $query = $this->db->get('penempatan',$number,$offset)->result();		
	}
 
	function jumlah_penempatan(){
		return $this->db->get('penempatan')->num_rows();
	}
	
	//Query Lulusan
	public function tampil_lulusan()
	{
		return $this->db->get('lulusan');
	}

	public function hapus_lulusan($id)
	{
		return $this->db->delete('lulusan', array('id_lulusan' => $id));
	}
	
	function data_lulusan($number,$offset){
		return $query = $this->db->get('lulusan',$number,$offset)->result();		
	}
 
	function jumlah_lulusan(){
		return $this->db->get('lulusan')->num_rows();
	}
	
	//Query Personil
	public function tampil_personil()
	{
		return $this->db->get('personil');
	}

	public function hapus_personil($id)
	{
		return $this->db->delete('personil', array('id_personil' => $id));
	}
	
	function data_personil($number,$offset){
		return $query = $this->db->get('personil',$number,$offset)->result();		
	}
 
	function jumlah_personil(){
		return $this->db->get('personil')->num_rows();
	}
	
	//Query Lowongan
	public function tampil_lowongan()
	{
		return $this->db->get('lowongan');
	}

	public function hapus_lowongan($id)
	{
		return $this->db->delete('lowongan', array('id_lowongan' => $id));
	}
}
