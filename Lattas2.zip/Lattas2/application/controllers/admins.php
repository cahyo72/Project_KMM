<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class admins extends CI_Controller {

	function index(){
		
		/*$a['alumni']	= $this->m_admins->tampil_alumni()->num_rows();//untuk ambil data dari file model_alumni.php dengan function tampil_alumni
		$a['lembaga']	= $this->m_admins->tampil_lembaga()->num_rows();
		$a['kejuruan']	= $this->m_admins->tampil_kejuruan()->num_rows();
		$a['penempatan'] = $this->m_admins->tampil_penempatan()->num_rows();
		$a['lulusan'] = $this->m_admins->tampil_lulusan()->num_rows();
		$a['personil'] = $this->m_admins->tampil_personil()->num_rows();
		$a['lowongan'] = $this->m_admins->tampil_lowongan()->num_rows();*/
		$a['page']	= "home";
		$this->load->view('admin/index', $a);
	}
	
	function __construct(){
		parent::__construct();
		$this->load->library(array('fpdf_gen','pagination'));
		$this->load->helper(array('url','form'));
		$this->load->model('m_admins');
	}

	/* Fungsi Alumni */
	function alumni_lulus(){
		$a['data']	= $this->m_admins->tampil_alumni_lulus()->result_object();
		$a['page']	= "alumni";
		
		$this->load->view('admin/index', $a);
	}
	
	function alumni_tlulus(){
		$a['data']	= $this->m_admins->tampil_alumni_tlulus()->result_object();
		$a['page']	= "alumni_tlulus";
		
		$this->load->view('admin/index', $a);
	}
	
	function alumni_diagram(){
		$a['page']	= "diagram_alumni";
		
		$this->load->view('admin/index', $a);
	}

	function tambah_alumni(){
		$a['page']	= "tambah_alumni";
		
		$this->load->view('admin/index', $a);
	}

	function insert_alumni(){
		
		$ta = $this->input->post('ta');
		$nama = $this->input->post('nama');
		$tempatlahir = $this->input->post('tempatlahir');
		$tgllahir = $this->input->post('tgllahir');
		$pendidikan = $this->input->post('pendidikan');
		$alamat = $this->input->post('alamat');
		$kabupaten = $this->input->post('kabupaten');
		$provinsi = $this->input->post('provinsi');
		$nohp = $this->input->post('nohp');
		$kejuruan = $this->input->post('kejuruan');
		$keterangan = $this->input->post('keterangan');
		
		$object = array('ta' => $ta,'nama' => $nama,'tempatlahir' => $tempatlahir,'tgllahir' => $tgllahir,'pendidikan' => $pendidikan,'alamat' => $alamat,'kabupaten' => $kabupaten,'provinsi' => $provinsi,'nohp' => $nohp,'kejuruan' => $kejuruan,'keterangan' => $keterangan);
		$this->db->insert('alumni', $object);

		redirect('index.php/admins/alumni_lulus','refresh');
	}

	function edit_alumni($id){
		$a['editdata']	= $this->db->get_where('alumni',array('kode_alumni'=>$id))->result_object();		
		$a['page']	= "edit_alumni";
		
		$this->load->view('admin/index', $a);
	}

	function update_alumni(){
		$id = $this->input->post('id');
		$ta = $this->input->post('ta');
		$nama = $this->input->post('nama');
		$tempatlahir = $this->input->post('tempatlahir');
		$tgllahir = $this->input->post('tgllahir');
		$pendidikan = $this->input->post('pendidikan');
		$alamat = $this->input->post('alamat');
		$kabupaten = $this->input->post('kabupaten');
		$provinsi = $this->input->post('provinsi');
		$nohp = $this->input->post('nohp');
		$kejuruan = $this->input->post('kejuruan');
		$keterangan = $this->input->post('keterangan');
		
		$object = array('ta' => $ta,'nama' => $nama,'tempatlahir' => $tempatlahir,'tgllahir' => $tgllahir,'pendidikan' => $pendidikan,'alamat' => $alamat,'kabupaten' => $kabupaten,'provinsi' => $provinsi,'nohp' => $nohp,'kejuruan' => $kejuruan,'keterangan' => $keterangan);
		$this->db->where('kode_alumni', $id);
		$this->db->update('alumni', $object); 

		redirect('index.php/admins/alumni_lulus','refresh');
	}

	function hapus_alumni($id){
		
		$this->m_admins->hapus_alumni($id);
		redirect('index.php/admins/alumni','refresh');
	}
	
	function cetak_alumni_lulus(){  
		$this->load->database();
		$jumlah_alumni = $this->m_admins->jumlah_alumni_lulus();
		$this->load->library('pagination');
		$config['base_url'] = base_url().'index.php/admins/cetak_alumni_lulus';
		$config['total_rows'] = $jumlah_alumni;
		$config['per_page'] = 10;
		$from = $this->uri->segment(3);
		$this->pagination->initialize($config);		
		$data['alumni'] = $this->m_admins->data_alumni_lulus($config['per_page'],$from);
		$this->load->view('admin/c_alumni_lulus',$data);
	}
	
	function cetak_alumni_tlulus(){  
		$this->load->database();
		$jumlah_alumni = $this->m_admins->jumlah_alumni_tlulus();
		$this->load->library('pagination');
		$config['base_url'] = base_url().'index.php/admins/cetak_alumni_tlulus';
		$config['total_rows'] = $jumlah_alumni;
		$config['per_page'] = 10;
		$from = $this->uri->segment(3);
		$this->pagination->initialize($config);		
		$data['alumni'] = $this->m_admins->data_alumni_tlulus($config['per_page'],$from);
		$this->load->view('admin/c_alumni_tlulus',$data);
	}
	
	
	/* Fungsi Lembaga */
	function lembaga(){
		$a['data']	= $this->m_admins->tampil_lembaga()->result_object();
		$a['page']	= "lembaga";
		
		$this->load->view('admin/index', $a);
	}

	function tambah_lembaga(){
		$a['page']	= "tambah_lembaga";
		
		$this->load->view('admin/index', $a);
	}

	function insert_lembaga(){
		$nama = $this->input->post('nama');
		$alamat = $this->input->post('alamat');
		$telp = $this->input->post('telp');
		$penanggung_jawab = $this->input->post('penanggung_jawab');
		$tgl_izin = $this->input->post('tgl_izin');
		$kejuruan = $this->input->post('kejuruan');
		$object = array('nama' => $nama,'alamat' => $alamat,'telp' => $telp,'penanggung_jawab' => $penanggung_jawab,'tgl_izin' => $tgl_izin,'kejuruan' => $kejuruan);
		$this->db->insert('lembaga', $object);

		redirect('index.php/admins/lembaga','refresh');
	}

	function edit_lembaga($id){
		$a['editdata']	= $this->db->get_where('lembaga',array('kode_lembaga'=>$id))->result_object();		
		$a['page']	= "edit_lembaga";
		
		$this->load->view('admin/index', $a);
	}

	function update_lembaga(){
		$id = $this->input->post('id');
		$nama = $this->input->post('nama');
		$alamat = $this->input->post('alamat');
		$telp = $this->input->post('telp');
		$penanggung_jawab = $this->input->post('penanggung_jawab');
		$tgl_izin = $this->input->post('tgl_izin');
		$kejuruan = $this->input->post('kejuruan');
		$object = array('nama' => $nama,'alamat' => $alamat,'telp' => $telp,'penanggung_jawab' => $penanggung_jawab,'tgl_izin' => $tgl_izin,'kejuruan' => $kejuruan);
		$this->db->where('kode_lembaga', $id);
		$this->db->update('lembaga', $object); 

		redirect('index.php/admins/lembaga','refresh');
	}

	function hapus_lembaga($id){
		
		$this->m_admins->hapus_lembaga($id);
		redirect('index.php/admins/lembaga','refresh');
	}
	
	function cetak_lembaga(){  
		$this->load->database();
		$jumlah_lembaga = $this->m_admins->jumlah_lembaga();
		$this->load->library('pagination');
		$config['base_url'] = base_url().'index.php/admins/cetak_lembaga';
		$config['total_rows'] = $jumlah_lembaga;
		$config['per_page'] = 10;
		$from = $this->uri->segment(3);
		$this->pagination->initialize($config);		
		$data['lembaga'] = $this->m_admins->data_lembaga($config['per_page'],$from);
		$this->load->view('admin/c_lembaga',$data);
	}
	
	//Fungsi kejuruan
	function kejuruan(){
		$a['data']	= $this->m_admins->tampil_kejuruan()->result_object();
		$a['page']	= "kejuruan";
		
		$this->load->view('admin/index', $a);
	}

	function tambah_kejuruan(){
		$a['page']	= "tambah_kejuruan";
		
		$this->load->view('admin/index', $a);
	}

	function insert_kejuruan(){
		//foreach ($_POST as $key => $value) { $query = $conn->query("INSERT INTO `kejuruan` (`nama_kejuruan`) VALUES ('$value');"); }
		$nama_kejuruan = $this->input->post('nama_kejuruan');
		$object = array('nama_kejuruan' => $nama_kejuruan);
		$this->db->insert('kejuruan', $object);

		redirect('index.php/admins/kejuruan','refresh');
	}

	function edit_kejuruan($id){
		$a['editdata']	= $this->db->get_where('kejuruan',array('kode_kejuruan'=>$id))->result_object();		
		$a['page']	= "edit_kejuruan";
		
		$this->load->view('admin/index', $a);
	}

	function update_kejuruan(){
		$id = $this->input->post('id');
		$nama_kejuruan = $this->input->post('nama_kejuruan');
		$object = array('nama_kejuruan' => $nama_kejuruan);
		$this->db->where('kode_kejuruan', $id);
		$this->db->update('kejuruan', $object); 

		redirect('index.php/admins/kejuruan','refresh');
	}

	function hapus_kejuruan($id){
		
		$this->m_admins->hapus_kejuruan($id);
		redirect('index.php/admins/kejuruan','refresh');
	}
	
	//Fungsi penempatan
	function penempatan(){
		$a['data']	= $this->m_admins->tampil_penempatan()->result_object();
		$a['page']	= "penempatan";
		
		$this->load->view('admin/index', $a);
	}

	function tambah_penempatan(){
		$a['page']	= "tambah_penempatan";
		
		$this->load->view('admin/index', $a);
	}

	function insert_penempatan(){
		
		$tahun = $this->input->post('tahun');
		$nama_peserta = $this->input->post('nama_peserta');
		$kejuruan = $this->input->post('kejuruan');
		$lembaga = $this->input->post('lembaga');
		$sertifikasi = $this->input->post('sertifikasi');
		$nama_perusahaan = $this->input->post('nama_perusahaan');
		$alamat_perusahaan = $this->input->post('alamat_perusahaan');
		$object = array('tahun' => $tahun,'nama_peserta' => $nama_peserta,'kejuruan' => $kejuruan,'lembaga' => $lembaga,'sertifikasi' => $sertifikasi,'nama_perusahaan' => $nama_perusahaan,'alamat_perusahaan' => $alamat_perusahaan);
		$this->db->insert('penempatan', $object);

		redirect('index.php/admins/penempatan','refresh');
	}

	function edit_penempatan($id){
		$a['editdata']	= $this->db->get_where('penempatan',array('kode_penempatan'=>$id))->result_object();		
		$a['page']	= "edit_penempatan";
		
		$this->load->view('admin/index', $a);
	}

	function update_penempatan(){
		$id = $this->input->post('id');
		$tahun = $this->input->post('tahun');
		$nama_peserta = $this->input->post('nama_peserta');
		$kejuruan = $this->input->post('kejuruan');
		$lembaga = $this->input->post('lembaga');
		$sertifikasi = $this->input->post('sertifikasi');
		$nama_perusahaan = $this->input->post('nama_perusahaan');
		$alamat_perusahaan = $this->input->post('alamat_perusahaan');
		$object = array('tahun' => $tahun,'nama_peserta' => $nama_peserta,'kejuruan' => $kejuruan,'lembaga' => $lembaga,'sertifikasi' => $sertifikasi,'nama_perusahaan' => $nama_perusahaan,'alamat_perusahaan' => $alamat_perusahaan);
		$this->db->where('kode_penempatan', $id);
		$this->db->update('penempatan', $object); 

		redirect('index.php/admins/penempatan','refresh');
	}

	function hapus_penempatan($id){
		
		$this->m_admins->hapus_penempatan($id);
		redirect('index.php/admins/penempatan','refresh');
	}
	
	function cetak_penempatan(){  
		$this->load->database();
		$jumlah_penempatan = $this->m_admins->jumlah_penempatan();
		$this->load->library('pagination');
		$config['base_url'] = base_url().'index.php/admins/cetak_penempatan';
		$config['total_rows'] = $jumlah_penempatan;
		$config['per_page'] = 10;
		$from = $this->uri->segment(3);
		$this->pagination->initialize($config);		
		$data['penempatan'] = $this->m_admins->data_penempatan($config['per_page'],$from);
		$this->load->view('admin/c_penempatan',$data);
	}
	
	//Fungsi lulusan
	function lulusan(){
		$a['data']	= $this->m_admins->tampil_lulusan()->result_object();
		$a['page']	= "lulusan";
		
		$this->load->view('admin/index', $a);
	}

	function tambah_lulusan(){
		$a['page']	= "tambah_lulusan";
		
		$this->load->view('admin/index', $a);
	}

	function insert_lulusan(){
		  	
		$identitas_lembaga = $this->input->post('identitas_lembaga');
		$nama_pimpinan = $this->input->post('nama_pimpinan');
		$no_ijin = $this->input->post('no_ijin');
		$kejuruan = $this->input->post('kejuruan');
		$kapasitas = $this->input->post('kapasitas');
		$dilatih_l = $this->input->post('dilatih_l');
		$dilatih_p = $this->input->post('dilatih_p');
		$lulusan_l = $this->input->post('lulusan_l');
		$lulusan_p = $this->input->post('lulusan_p');
		$perusahaan_l = $this->input->post('perusahaan_l');
		$perusahaan_p = $this->input->post('perusahaan_p');
		$mandiri_l = $this->input->post('mandiri_l');
		$mandiri_p = $this->input->post('mandiri_p');
		$object = array('identitas_lembaga' => $identitas_lembaga,'nama_pimpinan' => $nama_pimpinan,'no_ijin' => $no_ijin,'kejuruan' => $kejuruan,'kapasitas' => $kapasitas,'dilatih_l' => $dilatih_l,'dilatih_p' => $dilatih_p,'lulusan_l' => $lulusan_l,'lulusan_p' => $lulusan_p,'perusahaan_l' => $perusahaan_l,'perusahaan_p' => $perusahaan_p,'mandiri_l' => $mandiri_l,'mandiri_p' => $mandiri_p);
		$this->db->insert('lulusan', $object);

		redirect('index.php/admins/lulusan','refresh');
	}

	function edit_lulusan($id){
		$a['editdata']	= $this->db->get_where('lulusan',array('id_lulusan'=>$id))->result_object();		
		$a['page']	= "edit_lulusan";
		
		$this->load->view('admin/index', $a);
	}

	function update_lulusan(){
		$id = $this->input->post('id');
		$identitas_lembaga = $this->input->post('identitas_lembaga');
		$nama_pimpinan = $this->input->post('nama_pimpinan');
		$no_ijin = $this->input->post('no_ijin');
		$kejuruan = $this->input->post('kejuruan');
		$kapasitas = $this->input->post('kapasitas');
		$dilatih_l = $this->input->post('dilatih_l');
		$dilatih_p = $this->input->post('dilatih_p');
		$lulusan_l = $this->input->post('lulusan_l');
		$lulusan_p = $this->input->post('lulusan_p');
		$perusahaan_l = $this->input->post('perusahaan_l');
		$perusahaan_p = $this->input->post('perusahaan_p');
		$mandiri_l = $this->input->post('mandiri_l');
		$mandiri_p = $this->input->post('mandiri_p');
		$object = array('identitas_lembaga' => $identitas_lembaga,'nama_pimpinan' => $nama_pimpinan,'no_ijin' => $no_ijin,'kejuruan' => $kejuruan,'kapasitas' => $kapasitas,'dilatih_l' => $dilatih_l,'dilatih_p' => $dilatih_p,'lulusan_l' => $lulusan_l,'lulusan_p' => $lulusan_p,'perusahaan_l' => $perusahaan_l,'perusahaan_p' => $perusahaan_p,'mandiri_l' => $mandiri_l,'mandiri_p' => $mandiri_p);
		$this->db->where('id_lulusan', $id);
		$this->db->update('lulusan', $object); 

		redirect('index.php/admin/lulusan','refresh');
	}

	function hapus_lulusan($id){
		
		$this->m_admins->hapus_lulusan($id);
		redirect('index.php/admins/lulusan','refresh');
	}
	
	function cetak_lulusan(){  
		$this->load->database();
		$jumlah_lulusan = $this->m_admins->jumlah_lulusan();
		$this->load->library('pagination');
		$config['base_url'] = base_url().'index.php/admins/cetak_lulusan';
		$config['total_rows'] = $jumlah_lulusan;
		$config['per_page'] = 10;
		$from = $this->uri->segment(3);
		$this->pagination->initialize($config);		
		$data['lulusan'] = $this->m_admins->data_lulusan($config['per_page'],$from);
		$this->load->view('admin/c_lulusan',$data);
	}
	
	//Fungsi personil
	function personil(){
		$a['data']	= $this->m_admins->tampil_personil()->result_object();
		$a['page']	= "personil";
		
		$this->load->view('admin/index', $a);
	}

	function tambah_personil(){
		$a['page']	= "tambah_personil";
		
		$this->load->view('admin/index', $a);
	}

	function insert_personil(){
		
		$identitas_lembaga = $this->input->post('identitas_lembaga');
		$nama_pimpinan = $this->input->post('nama_pimpinan');
		$kejuruan = $this->input->post('kejuruan');
		$in_slta_l = $this->input->post('in_slta_l');
		$in_slta_p = $this->input->post('in_slta_p');
		$in_d3_l = $this->input->post('in_d3_l');
		$in_d3_p = $this->input->post('in_d3_p');
		$in_s1_l = $this->input->post('in_s1_l');
		$in_s1_p = $this->input->post('in_s1_p');
		$in_s2_l = $this->input->post('in_s2_l');
		$in_s2_p = $this->input->post('in_s2_p');
		$tp_slta_l = $this->input->post('tp_slta_l');
		$tp_slta_p = $this->input->post('tp_slta_p');
		$tp_d3_l = $this->input->post('tp_d3_l');
		$tp_d3_p = $this->input->post('tp_d3_p');
		$tp_s1_l = $this->input->post('tp_s1_l');
		$tp_s1_p = $this->input->post('tp_s1_p');
		$tp_s2_l = $this->input->post('tp_s1_p');
		$tp_s2_p = $this->input->post('tp_s2_p');
		$object = array('identitas_lembaga' => $identitas_lembaga,'nama_pimpinan' => $nama_pimpinan,'kejuruan' => $kejuruan,'in_slta_l' => $in_slta_l,'in_slta_p' => $in_slta_p,'in_d3_l' => $in_d3_l,'in_d3_p' => $in_d3_p,'in_s1_l' => $in_s1_l,'in_s1_p' => $in_s1_p,'in_s2_l' => $in_s2_l,'in_s2_p' => $in_s2_p,'tp_slta_l' => $tp_slta_l,'tp_slta_p' => $tp_slta_p,'tp_d3_l' => $tp_d3_l,'tp_d3_p' => $tp_d3_p,'tp_s1_l' => $tp_s1_l,'tp_s1_p' => $tp_s1_p,'tp_s2_l' => $tp_s2_l,'tp_s2_p' => $tp_s2_p);
		$this->db->insert('personil', $object);

		redirect('index.php/admins/personil','refresh');
	}

	function edit_personil($id){
		$a['editdata']	= $this->db->get_where('personil',array('id_personil'=>$id))->result_object();		
		$a['page']	= "edit_personil";
		
		$this->load->view('admin/index', $a);
	}

	function update_personil(){
		$id = $this->input->post('id');
		$identitas_lembaga = $this->input->post('identitas_lembaga');
		$nama_pimpinan = $this->input->post('nama_pimpinan');
		$kejuruan = $this->input->post('kejuruan');
		$in_slta_l = $this->input->post('in_slta_l');
		$in_slta_p = $this->input->post('in_slta_p');
		$in_d3_l = $this->input->post('in_d3_l');
		$in_d3_p = $this->input->post('in_d3_p');
		$in_s1_l = $this->input->post('in_s1_l');
		$in_s1_p = $this->input->post('in_s1_p');
		$in_s2_l = $this->input->post('in_s2_l');
		$in_s2_p = $this->input->post('in_s2_p');
		$tp_slta_l = $this->input->post('tp_slta_l');
		$tp_slta_p = $this->input->post('tp_slta_p');
		$tp_d3_l = $this->input->post('tp_d3_l');
		$tp_d3_p = $this->input->post('tp_d3_p');
		$tp_s1_l = $this->input->post('tp_s1_l');
		$tp_s1_p = $this->input->post('tp_s1_p');
		$tp_s2_l = $this->input->post('tp_s1_p');
		$tp_s2_p = $this->input->post('tp_s2_p');
		$object = array('identitas_lembaga' => $identitas_lembaga,'nama_pimpinan' => $nama_pimpinan,'kejuruan' => $kejuruan,'in_slta_l' => $in_slta_l,'in_slta_p' => $in_slta_p,'in_d3_l' => $in_d3_l,'in_d3_p' => $in_d3_p,'in_s1_l' => $in_s1_l,'in_s1_p' => $in_s1_p,'in_s2_l' => $in_s2_l,'in_s2_p' => $in_s2_p,'tp_slta_l' => $tp_slta_l,'tp_slta_p' => $tp_slta_p,'tp_d3_l' => $tp_d3_l,'tp_d3_p' => $tp_d3_p,'tp_s1_l' => $tp_s1_l,'tp_s1_p' => $tp_s1_p,'tp_s2_l' => $tp_s2_l,'tp_s2_p' => $tp_s2_p);
		$this->db->where('id_personil', $id);
		$this->db->update('personil', $object); 

		redirect('index.php/admin/personil','refresh');
	}

	function hapus_personil($id){
		
		$this->m_admins->hapus_personil($id);
		redirect('index.php/admins/personil','refresh');
	}
	
	function cetak_personil(){  
		$this->load->database();
		$jumlah_personil = $this->m_admins->jumlah_personil();
		$this->load->library('pagination');
		$config['base_url'] = base_url().'index.php/admins/cetak_personil';
		$config['total_rows'] = $jumlah_personil;
		$config['per_page'] = 10;
		$from = $this->uri->segment(3);
		$this->pagination->initialize($config);		
		$data['personil'] = $this->m_admins->data_personil($config['per_page'],$from);
		$this->load->view('admin/c_personil',$data);
	}
	
	//Fungsi lowongan
	function lowongan(){
		$a['data']	= $this->m_admins->tampil_lowongan()->result_object();
		$a['page']	= "lowongan";
		
		$this->load->view('admin/index', $a);
	}

	function tambah_lowongan(){
		$a['page']	= "tambah_lowongan";
		
		$this->load->view('admin/index', $a);
	}

	function insert_lowongan(){
		
		$nama_perusahaan = $this->input->post('nama_perusahaan');
		$info = $this->input->post('info');
		$object = array('nama_perusahaan' => $nama_perusahaan,'info' => $info);
		$this->db->insert('lowongan', $object);

		redirect('index.php/admins/lowongan','refresh');
	}

	function edit_lowongan($id){
		$a['editdata']	= $this->db->get_where('lowongan',array('id_lowongan'=>$id))->result_object();		
		$a['page']	= "edit_lowongan";
		
		$this->load->view('admin/index', $a);
	}

	function update_lowongan(){
		$id = $this->input->post('id');
		$lowongan = $this->input->post('lowongan');
		$object = array('lowongan' => $lowongan);
		$this->db->where('id_lowongan', $id);
		$this->db->update('lowongan', $object); 

		redirect('index.php/admins/lowongan','refresh');
	}

	function hapus_lowongan($id){
		
		$this->m_admins->hapus_lowongan($id);
		redirect('index.php/admins/lowongan','refresh');
	}
}

