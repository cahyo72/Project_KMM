<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              Tambah
              <small>Penempatan</small>
            </h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="<?php echo base_url(); ?>index.php/admins/penempatan">Penempatan</a></li>
              <li class="active">Tambah</li>
              <!--
              <li><a href="#">Layout</a></li>
              <li class="active">Top Navigation</li>
              -->
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Form Tambah Data Penempatan</h3>
              </div>
              <div class="box-body">
                <!-- form start -->
                <?php echo form_open('index.php/admins/insert_penempatan'); ?>
					
                  <div class="form-group">
						<label>Tahun Angkatan</label>
						<select name="tahun"  class="form-control">
						<option>2014</option>
						<option>2015</option>
						<option>2016</option>
						<option>2017</option>
						</select>
				 </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nama Peserta</label>
                      <select name="nama_peserta" class="form-control">
                        <?php  
                        $kode_alumni = $this->db->query("SELECT * FROM alumni")->result();
                        foreach ($kode_alumni as $nama_peserta) {
                          echo "<option  value='$nama_peserta->nama'>".ucwords($nama_peserta->nama)."</option>"; 
                        }
                        ?>
                      </select>
                  </div>
				   <div class="form-group">
                    <label for="exampleInputEmail1">Kejuruan</label>
                      <select name="kejuruan" class="form-control" multiple="multiple">
                        <?php  
                        $kode_kejuruan = $this->db->query("SELECT * FROM kejuruan")->result();
                        foreach ($kode_kejuruan as $kejuruan) {
                          echo "<option  value='$kejuruan->nama_kejuruan'>".ucwords($kejuruan->nama_kejuruan)."</option>"; 
                        }
                        ?>
                      </select>
					  </div>
					  
					  <div class="form-group">
                    <label for="exampleInputEmail1">Lembaga</label>
                      <select name="lembaga" class="form-control" multiple="multiple">
                        <?php  
                        $kode_lembaga = $this->db->query("SELECT * FROM lembaga")->result();
                        foreach ($kode_lembaga as $lembaga) {
                          echo "<option  value='$lembaga->nama'>".ucwords($lembaga->nama)."</option>"; 
                        }
                        ?>
                      </select>
					  </div>
					  
				  <div class="form-group">
                      <label>Sertifikasi</label>
						<select name="sertifikasi"  class="form-control">
						<option>Iya</option>
						<option>Tidak</option>
						</select>
                  </div>
				  
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nama Perusahaan</label>
                      <input type="text" class="form-control" name="nama_perusahaan" />
                  </div>
				  
				  <div class="form-group">
                    <label for="exampleInputEmail1">Alamat Perusahaan</label>
                      <input type="text" class="form-control" name="alamat_perusahaan" />
                  </div>
				  
                  <a href="<?php echo base_url(); ?>index.php/admins/penempatan" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Batal</a>
                  <button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                <?php echo form_close(); ?>
                
              </div><!-- /.box-body -->
            </div><!-- /.box -->
          </section><!-- /.content -->
        </div>