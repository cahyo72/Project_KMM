<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              Edit
              <small>Penempatan</small>
            </h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="<?php echo base_url(); ?>index.php/admins/penempatan">Penempatan</a></li>
              <li class="active">Edit</li>
              <!--
              <li><a href="#">Layout</a></li>
              <li class="active">Top Navigation</li>
              -->
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Form Edit Data Penempatan</h3>
              </div>
              <div class="box-body">
                <!-- form start -->
                <?php echo form_open('index.php/admins/update_penempatan'); ?>
                <?php  
                foreach ($editdata as $data):
                ?>
                   <div class="form-group">
						<label>Tahun Angkatan</label>
						<select name="tahun"  class="form-control">
						<option>2014</option>
						<option>2015</option>
						<option>2016</option>
						<option>2017</option>
						</select>
				 </div>
				   <div class="form-group">
                    <label for="exampleInputEmail1">Nama Peserta</label>
                      <select name="nama_peserta" class="form-control">
                        <?php
                        $nama_peserta = $this->db->query("SELECT * FROM alumni")->result();
                        
                        if (empty($nama_peserta)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($nama_peserta as $nama_peserta){
                        ?>
                       <option <?php if( $data->nama_peserta == $nama_peserta->kode_alumni) {echo "selected"; } ?> value='<?php echo $nama_peserta->nama;?>'><?php echo $nama_peserta->nama;?></option>

                        <?php 
                          } 
                          }
                        ?>
                      </select>
                  </div>
				    <div class="form-group">
                    <label for="exampleInputEmail1">Kejuruan</label>
                      <select name="kejuruan" class="form-control" multiple="multiple">
                        <?php
                        $kejuruan = $this->db->query("SELECT * FROM kejuruan")->result();
                        
                        if (empty($kejuruan)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($kejuruan as $kejuruan){
                        ?>
                       <option <?php if( $data->kejuruan == $kejuruan->kode_kejuruan) {echo "selected"; } ?> value='<?php echo $kejuruan->nama_kejuruan ;?>'><?php echo $kejuruan->nama_kejuruan ;?></option>

                        <?php 
                          } 
                          }
                        ?>
                      </select>
                  </div>
				   <div class="form-group">
                    <label for="exampleInputEmail1">Lembaga</label>
                      <select name="lembaga" class="form-control" multiple="multiple">
                        <?php
                        $lembaga = $this->db->query("SELECT * FROM lembaga")->result();
                        
                        if (empty($lembaga)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($lembaga as $lembaga){
                        ?>
                       <option <?php if( $data->lembaga == $lembaga->kode_lembaga) {echo "selected"; } ?> value='<?php echo $lembaga->nama ;?>'><?php echo $lembaga->nama ;?></option>

                        <?php 
                          } 
                          }
                        ?>
                      </select>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Sertifikasi</label>
                      <input type="text" class="form-control" name="sertifikasi" value="<?php echo $data->sertifikasi ?>"/>
                  </div>
				   <div class="form-group">
                    <label for="exampleInputEmail1">Nama Perusahaan</label>
                      <input type="text" class="form-control" name="nama_perusahaan" value="<?php echo $data->nama_perusahaan ?>"/>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Alamat Perusahaan</label>
                      <input type="text" class="form-control" name="alamat_perusahaan" value="<?php echo $data->alamat_perusahaan ?>"/>
                  </div>
				  
                  <input type="hidden" name="id" value="<?php echo $data->kode_penempatan ?>">
                  <a href="<?php echo base_url(); ?>index.php/admins/penempatan" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Batal</a>
                  <button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                <?php endforeach ?>
                <?php echo form_close(); ?>
              </div><!-- /.box-body -->
            </div><!-- /.box -->
          </section><!-- /.content -->
		  </div>
