<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              Edit
              <small>Lulusan</small>
            </h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="<?php echo base_url(); ?>index.php/admins/lulusan">Lulusan</a></li>
              <li class="active">Edit</li>
              <!--
              <li><a href="#">Layout</a></li>
              <li class="active">Top Navigation</li>
              -->
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Form Edit Data Lulusan</h3>
              </div>
              <div class="box-body">
                <!-- form start -->
                <?php echo form_open('index.php/admins/update_lulusan'); ?>
                <?php  
                foreach ($editdata as $data):
                ?>
               
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nama, Alamat dan No Telp</label>
                      <textarea name="identitas_lembaga" class="form-control" cols="30" rows="10"><?php echo $data->identitas_lembaga ?></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nama Pimpinan</label>
                      <input type="text" class="form-control" name="nama_pimpinan" value="<?php echo $data->nama_pimpinan ?>"/>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">No Ijin</label>
                      <input type="text" class="form-control" name="no_ijin" value="<?php echo $data->no_ijin ?>"/>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Kejuruan</label>
                      <select name="kejuruan" class="form-control">
                        <?php
                        $kejuruan = $this->db->query("SELECT * FROM kejuruan")->result();
                        
                        if (empty($kejuruan)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($kejuruan as $kejuruan){
                        ?>
                       <option <?php if( $data->kejuruan == $kejuruan->kode_kejuruan) {echo "selected"; } ?> value='<?php echo $kejuruan->nama_kejuruan ;?>'><?php echo $kejuruan->nama_kejuruan ;?></option>

                        <?php 
                          } 
                          }
                        ?>
                      </select>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Kapasitas Latih</label>
                      <input type="text" class="form-control" name="kapasitas" value="<?php echo $data->kapasitas ?>"/>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Jml Dilatih (L)</label>
                      <input type="text" class="form-control" name="dilatih_l" value="<?php echo $data->dilatih_l ?>"/>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Jml Dilatih (P)</label>
                      <input type="text" class="form-control" name="dilatih_p" value="<?php echo $data->dilatih_p ?>"/>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Jml Lulusan (L)</label>
                      <input type="text" class="form-control" name="lulusan_l" value="<?php echo $data->lulusan_l ?>"/>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Jml Lulusan (P)</label>
                      <input type="text" class="form-control" name="lulusan_p" value="<?php echo $data->lulusan_p ?>"/>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Bekerja di perusahaan (L)</label>
                      <input type="text" class="form-control" name="perusahaan_l" value="<?php echo $data->perusahaan_l ?>"/>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Bekerja di perusahaan (P)</label>
                      <input type="text" class="form-control" name="perusahaan_p" value="<?php echo $data->perusahaan_p ?>"/>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Bekerja Mandiri (L)</label>
                      <input type="text" class="form-control" name="mandiri_l" value="<?php echo $data->mandiri_l ?>"/>
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Bekerja Mandiri (P)</label>
                      <input type="text" class="form-control" name="mandiri_p" value="<?php echo $data->mandiri_p ?>"/>
                  </div>
				  
                  <input type="hidden" name="id" value="<?php echo $data->id_lulusan ?>">
                  <a href="<?php echo base_url(); ?>index.php/admins/lulusan" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Batal</a>
                  <button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                <?php endforeach ?>
                <?php echo form_close(); ?>
              </div><!-- /.box-body -->
            </div><!-- /.box -->
          </section><!-- /.content -->
