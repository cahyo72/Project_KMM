<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              Tambah
              <small>Personil</small>
            </h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="<?php echo base_url(); ?>index.php/admins/personil">Personil</a></li>
              <li class="active">Tambah</li>
              <!--
              <li><a href="#">Layout</a></li>
              <li class="active">Top Navigation</li>
              -->
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Form Tambah Data Personil</h3>
              </div>
              <div class="box-body">
                <!-- form start -->
                <?php echo form_open('index.php/admins/insert_personil'); ?>
					
					<div class="form-group">
                    <label for="exampleInputEmail1">Nama, Alamat dan No Telp</label>
                      <textarea name="identitas_lembaga" class="form-control" cols="30" rows="10" ></textarea>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Nama Pimpinan</label>
                      <input type="text" class="form-control" name="nama_pimpinan" />
                  </div>
				 <div class="form-group">
                    <label for="exampleInputEmail1">Kejuruan</label>
                      <select name="kejuruan" class="form-control" multiple="multiple">
                        <?php  
                        $kode_kejuruan = $this->db->query("SELECT * FROM kejuruan")->result();
                        foreach ($kode_kejuruan as $kejuruan) {
                          echo "<option  value='$kejuruan->nama_kejuruan'>".ucwords($kejuruan->nama_kejuruan)."</option>"; 
                        }
                        ?>
                      </select>
					  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Instruktur SLTA (L)</label>
                      <input type="text" class="form-control" name="in_slta_l" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Instruktur SLTA (P)</label>
                      <input type="text" class="form-control" name="in_slta_p" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Instruktur D3 (L)</label>
                      <input type="text" class="form-control" name="in_d3_l" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Instruktur D3 (P)</label>
                      <input type="text" class="form-control" name="in_d3_p" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Instruktur S1 (L)</label>
                      <input type="text" class="form-control" name="in_s1_l" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Instruktur S1 (P)</label>
                      <input type="text" class="form-control" name="in_s1_p" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Instruktur S2 (L)</label>
                      <input type="text" class="form-control" name="in_s2_l" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Instruktur S2 (P)</label>
                      <input type="text" class="form-control" name="in_s2_p" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Tenaga Pelatih SLTA (L)</label>
                      <input type="text" class="form-control" name="tp_slta_l" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Tenaga Pelatih SLTA (P)</label>
                      <input type="text" class="form-control" name="tp_slta_p" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Tenaga Pelatih D3 (L)</label>
                      <input type="text" class="form-control" name="tp_d3_l" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Tenaga Pelatih D3 (P)</label>
                      <input type="text" class="form-control" name="tp_d3_p" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Tenaga Pelatih S1 (L)</label>
                      <input type="text" class="form-control" name="tp_s1_l" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Tenaga Pelatih S1 (P)</label>
                      <input type="text" class="form-control" name="tp_s1_p" />
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Tenaga Pelatih S2 (L)</label>
                      <input type="text" class="form-control" name="tp_s2_l" />
                  </div>
				  <div class="form-group">
                    <label for="exampleInputEmail1">Tenaga Pelatih S2 (P)</label>
                      <input type="text" class="form-control" name="tp_s2_p" />
                  </div>
				  
                  <a href="<?php echo base_url(); ?>index.php/admins/personil" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Batal</a>
                  <button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                <?php echo form_close(); ?>
                
              </div><!-- /.box-body -->
            </div><!-- /.box -->
          </section><!-- /.content -->
        </div>