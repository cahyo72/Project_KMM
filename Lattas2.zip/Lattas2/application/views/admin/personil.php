<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Personil
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="index"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Personil</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">

        	<div class="row">          	
          	<div class="col-xs-12">
          		<div class="box">
                <div class="box-header">
                  <h3 class="box-title">
                  	<a href="<?php echo base_url(); ?>index.php/admins/tambah_personil" class="btn btn-sm btn-primary btn-flat"><i class="fa fa-edit"></i> Tambah</a>
                    <a href="<?php echo base_url(); ?>index.php/admins/cetak_personil" class="btn btn-sm btn-success btn-flat"><i class="fa fa-print"></i> Cetak</a>
				  </h3>
                  <div class="box-tools">
                  </div>
                </div><!-- /.box-header -->
				
                <div class="box-body table-responsive no-padding">
               
                  <table id="example1" class="table table-bordered table-hover dataTable">
                    <thead>
                      	<tr>
								  <th rowspan="4" >NO</th></center>
								  <th rowspan="4" ><center>NAMA, ALAMAT DAN NO TELP</center></th>
								  <th rowspan="4" >NAMA PIMPINAN</th>
								  <th rowspan="4" >KEJURUAN</th>
								  <th rowspan="1"colspan="16" ><center>JUMLAH</center></th>
								  <th rowspan="4">AKSI</th>
								</tr>
								<tr>
								 <td rowspan="1" colspan="8" >INSTRUKTUR</td>
								 <td rowspan="1" colspan="8" >TENAGA KEPELATIHAN</td>
								</tr>
								<tr>
								<td colspan="2" >SLTA</td>
								  <td colspan="2" >D3</td>
								  <td colspan="2" >S1</td>
								  <td colspan="2" >S2</td>
								  <td colspan="2" >SLTA</td>
								  <td colspan="2" >D3</td>
								  <td colspan="2" >S1</td>
								  <td colspan="2" >S2</td>
								</tr>
								<tr>
									  <td>L</td>
									  <td>P</td>
									  <td>L</td>
									  <td>P</td>
									  <td>L</td>
									  <td>P</td>
									  <td>L</td>
									  <td>P</td>
									  <td>L</td>
									  <td>P</td>
									  <td>L</td>
									  <td>P</td>
									  <td>L</td>
									  <td>P</td>
									  <td>L</td>
									  <td>P</td>
								</tr>
                    </thead>
					
                    <tbody>
                      	<?php  
                      	$no = 1;
                      	foreach ($data as $lihat):
                      	?>
                    	<tr>
                        <td><?php echo $no++ ?></td>
                    	<td><?php echo $lihat->identitas_lembaga?></td>
                    	<td><?php echo $lihat->nama_pimpinan?></td>
					  <td><?php echo ucfirst($lihat->kejuruan) ?></td> 
					  <td><?php echo ucfirst($lihat->in_slta_l) ?></td> 
					  <td><?php echo ucfirst($lihat->in_slta_p) ?></td> 
					  <td><?php echo ucfirst($lihat->in_d3_l) ?></td>
					  <td><?php echo ucfirst($lihat->in_d3_p) ?></td>
					  <td><?php echo ucfirst($lihat->in_s1_l) ?></td> 
					  <td><?php echo ucfirst($lihat->in_s1_p) ?></td> 
					  <td><?php echo ucfirst($lihat->in_s2_l) ?></td> 
					  <td><?php echo ucfirst($lihat->in_s2_p) ?></td>
					  <td><?php echo ucfirst($lihat->tp_slta_l) ?></td>
					  <td><?php echo ucfirst($lihat->tp_slta_p) ?></td> 
                      <td><?php echo ucfirst($lihat->tp_d3_l) ?></td> 
                      <td><?php echo ucfirst($lihat->tp_d3_p) ?></td> 
                      <td><?php echo ucfirst($lihat->tp_s1_l) ?></td>
					  <td><?php echo ucfirst($lihat->tp_s1_p) ?></td>
					  <td><?php echo ucfirst($lihat->tp_s2_l) ?></td> 
                      <td><?php echo ucfirst($lihat->tp_s2_p) ?></td> 				  
                        <td align="center">
                          <div class="btn-group" role="group">
                            <a href="<?php echo base_url(); ?>index.php/admins/edit_personil/<?php echo $lihat->id_personil ?>" class="btn btn-sm btn-primary btn-flat"><i class="fa fa-edit"></i> Edit</a>
                            <a href="<?php echo base_url(); ?>index.php/admins/hapus_personil/<?php echo $lihat->id_personil ?>" onclick="javascript: return confirm('Anda yakin akan menghapus data ini ?')" class="btn btn-sm btn-danger btn-flat"><i class="fa fa-trash"></i> Hapus</a>
                          </div>
                        </td>                  		
                    	</tr>
                    	<?php endforeach ?>
                    </tbody>
                  </table>
                  
                </div><!-- /.box-body -->
                </div>
             </div>
          </div>
          
         

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
