<!doctype html>
<html>
<head>
<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="<?php echo base_url(); ?>favicon.ico">

        <title>Sistem Informasi Lattas</title>
        <!-- Bootstrap core CSS -->
        <link href="<?php echo base_url(); ?>dist/css/bootstrap.css" rel="stylesheet">
        <!-- Bootstrap theme -->
        <link href="<?php echo base_url(); ?>dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="<?php echo base_url(); ?>dist/css/bootstrap-theme.css" rel="stylesheet">
		<!-- CSS Login -->
		<link href="<?php echo base_url(); ?>dist/css/login.css" rel="stylesheet">
    </head>

<body>
<!-- Left Image Side -->
<div class="left"></div>

<!-- Right login form side -->
	<div class="right">
	<div class="content">
  
    <h2>Silahkan Login</h2>
	 <?php
				 // Cetak session
				if($this->session->flashdata('sukses')) {
					echo '<p class="warning" style="margin: 10px 20px;">'.$this->session->flashdata('sukses').'</p>';
				}
				// Cetak error
				echo validation_errors('<p class="warning" style="margin: 10px 20px;">','</p>');
				?>
				
				<form action="<?php echo base_url('index.php/login') ?>" method="post">
				  <p>
					<label for="username">Username</label>
					<input type="text" name="username" id="username" placeholder="Enter Username">
					
				  </p>
				  <p>
					<label for="password">Password</label>
					<input type="password" name="password" id="password" placeholder="Enter Password">
				  </p>
				  <p>
				  <button input type="submit" name="submit" id="submit" value="Login" class="full">Log In</button>
				  </p>
				</form>
			</section>
			</div>
			</div>
  </div>
</div>

		<!-- Bootstrap core JavaScript
        ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="<?php echo base_url(); ?>dist/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url(); ?>dist/js/bootstrap.js"></script>
		<script src="<?php echo base_url(); ?>dist/js/npm.js"></script>
        
</body>
</html>