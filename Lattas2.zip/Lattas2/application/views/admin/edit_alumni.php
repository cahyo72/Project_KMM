<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
	  <meta charset="utf-8">
					  <meta name="viewport" content="width=device-width, initial-scale=1">
					  <title>jQuery UI Datepicker - Default functionality</title>
					  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
					  <link rel="stylesheet" href="/resources/demos/style.css">
        <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              Edit
              <small>Alumni</small>
            </h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="<?php echo base_url(); ?>index.php/admins/alumni">Alumni</a></li>
              <li class="active">Edit</li>
              <!--
              <li><a href="#">Layout</a></li>
              <li class="active">Top Navigation</li>
              -->
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Form Edit Data Alumni</h3>
              </div>
              <div class="box-body">
                <!-- form start -->
                <?php echo form_open('index.php/admins/update_alumni'); ?>
                <?php  
                foreach ($editdata as $data):
                ?>
				
				 <div class="form-group">
				   <div class="row">
				   <div class="col-lg-2" >
						<label>Tahun Angkatan</label>
						<select name="ta"  class="form-control">
						<option>2014</option>
						<option>2015</option>
						<option>2016</option>
						<option>2017</option>
						</select>
				 </div>
				  
				   <div class="col-lg-10" >                  
                    <label for="exampleInputEmail1">Nama Alumni</label>
                      <input type="text" class="form-control" name="nama" value="<?php echo $data->nama ?>"/>
                  </div>
					</div>
						</div>
						
                  <div class="form-group">
				  <div class="row">
				   <div class="col-lg-5" >
                    <label for="exampleInputEmail1">Tempat Lahir</label>
                      <select name="tempatlahir" class="form-control" >
                        <?php
                        $kabupaten = $this->db->query("SELECT * FROM kabupaten")->result();
                        
                        if (empty($kabupaten)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($kabupaten as $kabupaten){
                        ?>
                       <option <?php if( $data->kabupaten == $kabupaten->id_kabupaten) {echo "selected"; } ?> value='<?php echo $kabupaten->nama_kabupaten ;?>'><?php echo $kabupaten->nama_kabupaten ;?></option>

                        <?php 
                          } 
                          }
                        ?>
                      </select>
                  </div>
				  <div class="col-lg-4" >
                    <label for="date">Tanggal Lahir</label>
					 <input type="text" class="form-control" id="datepicker" data-date-format="yyyy-mm-dd" name="tgllahir" value="<?php echo $data->tgllahir ?>"/>
                  </div>
				   <div class="col-lg-3" >
				   <label>Pendidikan</label>
						<select name="pendidikan"  class="form-control" value="<?php echo $data->pendidikan ?>"/>
						<option>SMA</option>
						<option>SMK</option>
						<option>D3</option>
						<option>S1</option>
						</select>
						</div>
							</div>
								</div>

				  <div class="form-group">
				   <div class="row">
				   <div class="col-lg-7" >
                    <label for="exampleInputEmail1">Alamat</label>
                      <input type="text" class="form-control" name="alamat" value="<?php echo $data->alamat ?>" />
					</div>
					<div class="col-lg-2">
                      <label for="exampleInputEmail1">Kabupaten</label>
						 <select name="kabupaten" class="form-control" >
                        <?php
                        $kabupaten = $this->db->query("SELECT * FROM kabupaten")->result();
                        
                        if (empty($kabupaten)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($kabupaten as $kabupaten){
                        ?>
                       <option <?php if( $data->kabupaten == $kabupaten->id_kabupaten) {echo "selected"; } ?> value='<?php echo $kabupaten->nama_kabupaten ;?>'><?php echo $kabupaten->nama_kabupaten ;?></option>

                        <?php 
                          } 
                          }
                        ?>
                      </select>
                  </div>
				  <div class="col-lg-3 ">
                      <label >Provinsi</label>
						 <select name="provinsi" class="form-control" >
                        <?php
                        $provinsi = $this->db->query("SELECT * FROM provinsi")->result();
                        
                        if (empty($provinsi)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($provinsi as $provinsi){
                        ?>
                       <option <?php if( $data->provinsi == $provinsi->id_provinsi) {echo "selected"; } ?> value='<?php echo $provinsi->nama_provinsi ;?>'><?php echo $provinsi->nama_provinsi ;?></option>

                        <?php 
                          } 
                          }
                        ?>
                      </select>
                  </div>
					</div>
						</div>
					
				   <div class="form-group">
				   <div class="row">
				   <div class="col-lg-3" >
                    <label for="exampleInputEmail1">No HP</label>
                      <input type="text" class="form-control" name="nohp" />
                  </div>
				  <div class="col-lg-6">
				  <label for="exampleInputEmail1">Kejuruan</label>
                      <select name="kejuruan" class="form-control">
                        <?php
                        $kejuruan = $this->db->query("SELECT * FROM kejuruan")->result();
                        
                        if (empty($kejuruan)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($kejuruan as $kejuruan){
                        ?>
                       <option <?php if( $data->kejuruan == $kejuruan->kode_kejuruan) {echo "selected"; } ?> value='<?php echo $kejuruan->nama_kejuruan ;?>'><?php echo $kejuruan->nama_kejuruan ;?></option>

                        <?php 
                          } 
                          }
                        ?>
                      </select>
				  </div>
					<div class="col-lg-3" >
                    <label for="exampleInputEmail1">Keterangan</label>
                      <select name="keterangan"  class="form-control" value="<?php echo $data->keterangan ?>">
						<option>Lulus</option>
						<option>Tidak Lulus</option>
						</select>
                  </div>
					</div>
						</div>
				  
                  <input type="hidden" name="id" value="<?php echo $data->kode_alumni ?>">
                  <a href="<?php echo base_url(); ?>index.php/admins/alumni_lulus" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Batal</a>
                  <button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                <?php endforeach ?>
                <?php echo form_close(); ?>
              </div><!-- /.box-body -->
			  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
					  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
					  <script>
					  $( function() {
						$( "#datepicker" ).datepicker();
					  } );
					  </script>
            </div><!-- /.box -->
          </section><!-- /.content -->
        </div>