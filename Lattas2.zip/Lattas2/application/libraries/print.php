<?php
	session_start();
	require ('tables.php');
	include "../include/koneksi_db.php";
	
	class Cetak_Peserta extends Tables
	{
		function __construct() 
		{ 
			parent::__construct('P', 'cm', 'A4');
			$this->SetMargins(1, 1, 2); 
			$this->SetAutoPageBreak(true, 2);
		}
		
		function Title($jurusan, $lembaga, $angkatan)
		{	
			$this->SetFont('Arial', 'B', 8);
			$this->Cell(0, 0.5, "DAFTAR PENEMPATAN PESERTA", 0, 1, 'C');
			$this->Cell(0, 0.5, "KEGIATAN PENDIDIKAN DAN PELATIHAN KETERAMPILAN BAGI PENCARI KERJA", 0, 1, 'C');
			$this->Cell(0, 0.5, "PROGRAM PKTP DINSOSNAKERTRANS KOTA SURAKARTA", 0, 1, 'C');
			$this->Cell(0, 0.5, "KEJURUAN ".$jurusan." DI LPKS ".$lembaga, 0, 1, 'C');
			$this->Cell(0, 0.5, "TAHUN ".$angkatan, 0, 1, 'C');
			$this->Line(1, 3.5, 20, 3.5);
			$this->Line(1, 3.6, 20, 3.6);
		}
		
		function TitleLembaga()
		{	
			$this->SetFont('Arial', 'B', 8);
			$this->Cell(0, 0.5, "DAFTAR LEMBAGA PELAKSANA", 0, 1, 'C');
			$this->Cell(0, 0.5, "KEGIATAN PENDIDIKAN DAN PELATIHAN KETERAMPILAN BAGI PENCARI KERJA", 0, 1, 'C');
			$this->Cell(0, 0.5, "PROGRAM PKTP DINSOSNAKERTRANS KOTA SURAKARTA", 0, 1, 'C');
			$this->Line(1, 2.5, 20, 2.5);
			$this->Line(1, 2.6, 20, 2.6);
		}
		
		function HeaderTable($printkey)
		{
			if($printkey == 1)
			{
				$this->SetXY(1, 4);
				$this->SetFont('Arial', 'B', 8);
				$this->Cell(1, 0.7, "NO", 1, 0, 'C');
				$this->Cell(4, 0.7, "NAMA", 1, 0, 'C');
				$x = $this->GetX();
				$y = $this->GetY();
				$this->MultiCell(1.2, 0.35, "JENIS KEL.", 1, 'C');
				$this->SetXY(($x+1.20), $y);
				$this->Cell(3.8, 0.7, "TEMPAT TANGGAL LAHIR", 1, 0, 'C');
				$this->Cell(4, 0.7, "ALAMAT", 1, 0, 'C');
				$this->Cell(1.3, 0.7, "PEND.", 1, 0, 'C');
				$this->Cell(3.7, 0.7, "TEMPAT KERJA", 1, 0, 'C');
				$this->Ln();
			}
			else
			{
				$this->SetXY(1, 3);
				$this->SetFont('Arial', 'B', 8);
				$this->Cell(1, 0.7, "NO", 1, 0, 'C');
				$this->Cell(6, 0.7, "NAMA", 1, 0, 'C');
				$this->Cell(8, 0.7, "ALAMAT", 1, 0, 'C');
				$this->Cell(4, 0.7, "NO. TELP", 1, 0, 'C');
				$this->Ln();
			}
		}
	}
	
	$sql = $_SESSION['sql'];
	$printkey = $_SESSION['printkey'];
	
	$pdf = new Cetak_Peserta();
	$pdf->AddPage();
	$pdf->SetTitle('Cetak Dokumen');
	
	if($printkey == 1)
	{
		$query = mysql_query($sql, $konek);
		$result = mysql_fetch_array($query);
		$jurusan = strtoupper($result['kejuruan']);
		$lembaga = strtoupper($result['lembaga']);
		$angkatan = strtoupper($result['tahun']);
		
		$pdf->Title($jurusan, $lembaga, $angkatan);
		$pdf->HeaderTable($printkey);
		$pdf->SetFont('Arial', '', 8);
		$pdf->SetWidths(array(1, 4, 1.2, 3.8, 4, 1.3, 3.7));
		$pdf->SetAligns(array('C', 'L', 'C', 'C', 'L', 'C', 'L'));
		
		$i = 1;
		$query2 = mysql_query($sql, $konek);
		while($result = mysql_fetch_array($query2))
		{
			$pdf->Row(array($i, strtoupper($result['nama_peserta']), strtoupper($result['jk']), strtoupper($result['tempatlahir']).", ".date("j-n-Y", strtotime($result['tgllahir'])), strtoupper($result['alamat']), strtoupper($result['pendidikan']), strtoupper($result['k_penempatan'])), $printkey); $i++;
		}
	}
	else
	{
		$pdf->TitleLembaga();
		$pdf->HeaderTable($printkey);
		$pdf->SetFont('Arial', '', 8);
		$pdf->SetWidths(array(1, 6, 8, 4));
		$pdf->SetAligns(array('C', 'L', 'C', 'C'));
		
		$i = 1;
		$query = mysql_query($sql, $konek);
		while($result = mysql_fetch_array($query))
		{
			$pdf->Row(array($i, $result['nama'], $result['alamat'], $result['telp']), $printkey); $i++;
		}
	}
	
	$pdf->Output();
?>