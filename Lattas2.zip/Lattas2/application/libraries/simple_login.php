<?php if(! defined('BASEPATH')) exit('Akses langsung tidak diperbolehkan'); 

class simple_login {
	// SET SUPER GLOBAL
	var $CI = NULL;
	public function __construct() {
		$this->CI =& get_instance();
	}
	// Fungsi login
	public function login($username, $password) {
		$query = $this->CI->db->get_where('admin',array('username'=>$username,'password' => $password));
		if($query->num_rows() == 1) {
			$row 	= $this->CI->db->query('SELECT id_admin FROM admin where username = "'.$username.'"');
			$admin 	= $row->row();
			$id 	= $admin->id_admin;
			$this->CI->session->set_userdata('username', $username);
			$this->CI->session->set_userdata('id_admin', uniqid(rand()));
			$this->CI->session->set_userdata('id', $id);
			redirect('index.php/admins');
		}else{
			$this->CI->session->set_flashdata('sukses','Maaf Username dan Password Salah!!!');
			redirect('index.php/login');
		}
		return false;
	}
	// Proteksi halaman
	public function cek_login() {
		if($this->CI->session->userdata('username') == '') {
			$this->CI->session->set_flashdata('sukses','Anda Belum Melakukan Login');
			redirect('index.php/login');
		}
	}
	// Fungsi logout
	public function logout() {
		$this->CI->session->unset_userdata('username');
		$this->CI->session->unset_userdata('id_admin');
		$this->CI->session->unset_userdata('id');
		$this->CI->session->set_flashdata('sukses','Anda Berhasil Logout');
		redirect('index.php/login');
	}
}