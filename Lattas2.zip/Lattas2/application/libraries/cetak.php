<html>
	<header>
		<title>Cetak Dokumen</title>
	</header>
	
	<body>
		<iframe src="print.php"></iframe>
	</body>
</html>